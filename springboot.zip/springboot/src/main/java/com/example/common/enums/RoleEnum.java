package com.example.common.enums;

public enum RoleEnum {
    // 管理员
    ADMIN,
    // 电影院
    CINEMA,
    // 用户
    USER
}
